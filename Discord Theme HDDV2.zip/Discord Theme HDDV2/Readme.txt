Discord HDDV2 GTA V Special Themes

Requisite: https://github.com/rauenzi/BetterDiscordApp

Powerd by Gibbu - https://betterdiscordlibrary.com/themes/Frosted%20Glass

Copyright © 2020 All Rights Reserved